#include "include/features.h"

Features::Features()
{
}

Features::~Features()
{
}

// 计算跳变次数  
int Features::getHopCount(int i)  
{  
    int a[8] = {0};  
    int cnt = 0;  
    int k = 7;  
    while(i)  
    {  
        a[k] = i&1;  
        i = i >> 1;  
        --k;  
    }  
    for(k = 0; k < 7; k++)  
    {  
        if(a[k] != a[k+1])  
        {  
            ++cnt;  
        }  
    }  
    if(a[0] != a[7])  
    {  
        ++cnt;  
    }  
    return cnt;  
}  
  
// 降维数组 由256->59  
void Features::lbp59table(uchar *table)  
{  
    memset(table, 0, 256);  
    uchar temp = 1;  
    for(int i = 0; i < 256; i++)  
    {  
        if(getHopCount(i) <= 2)    // 跳变次数<=2 的为非0值  
        {  
            table[i] = temp;  
            temp ++;  
        }  
    }  
}  

void Features::uniformLBP(Mat &image, Mat &result, uchar *table)  
{  
    int countLBP[8] = {0,0,0,0,0,0,0,0};
    float countAll = 0;

    for(int y = 1; y < image.rows-1; y ++)  
    {  
        for(int x = 1; x < image.cols-1; x++)  
        {  
            uchar neighbor[8] = {0}; 
            neighbor[0] = image.at<uchar>(y-1, x-1);  
            neighbor[1] = image.at<uchar>(y-1, x);  
            neighbor[2] = image.at<uchar>(y-1, x+1);  
            neighbor[3] = image.at<uchar>(y, x+1);  
            neighbor[4] = image.at<uchar>(y+1, x+1);  
            neighbor[5] = image.at<uchar>(y+1, x);  
            neighbor[6] = image.at<uchar>(y+1, x-1);  
            neighbor[7] = image.at<uchar>(y, x-1);

            uchar center = image.at<uchar>(y, x);  

            uchar temp = 0;  
            for(int k = 0; k < 8; k++)  
            {  
                temp += (neighbor[k] >= center)* (1<<k);  // 计算LBP的值  
            }
            //cout<<int(temp)<<endl;
            //result.at<uchar>(y,x) = temp;
            result.at<uchar>(y-1,x-1) = table[temp];   //  降为59维空间  
        }  
    }
}  

///*
void Features::getLBPHistogram(Mat &image, float array[59])
{
    uchar value;
    for(int y = 0; y < image.rows; y ++)  
    {  
        for(int x = 0; x < image.cols; x++)  
        {  
            value = image.at<uchar>(y, x);
            array[int(value)]++;
        }  
    }

    //lbpHistogram Normalize
    float histValue = 0.0;
    for (int i = 0; i < 59; ++i)
    {
        array[i] /= float(image.rows * image.cols);
        //cout<<histValue<<" ";
    }
}

void Features::varianceCountLAB(Mat &image, float array[6])
{
    float meanLAB[3] = {0.0, 0.0, 0.0};
    float varianceLAB[3] = {0.0, 0.0, 0.0};

    int k = 0;

    for (int i = 0; i < 3; ++i)
    {
        meanLAB[i] = mean(image)[i];
        
        array[k++] = meanLAB[i];

        Vec3b value;
        for(int y = 0; y < image.rows; y ++)  
        {  
            for(int x = 0; x < image.cols; x++)  
            {  
                value = image.at<Vec3b>(y, x); 
                //cout<<int(value[0])<<endl; 
                varianceLAB[i] += pow((int(value[i]) - meanLAB[i]),2);
            }  
        }

        varianceLAB[i] /= (image.rows*image.cols);
        
        array[k++] = varianceLAB[i];  
    }
}
  
int Features::getFeature_Classify(Mat image0)  
{   
    float feature[65];
    for (int i = 0; i < 65; ++i)
    {
        feature[i] = 0;
    }

    uchar table[256];  
    lbp59table(table);

    Mat image;
    image.create(Size(image0.cols, image0.rows), 0);
    cvtColor(image0, image, CV_BGR2GRAY);

    //cout<<image.rows<<' '<<image.cols<<endl;

    Mat result;  
    result.create(Size(image.cols-2, image.rows-2), 0);
    uniformLBP(image, result, table); 

    getLBPHistogram(result, feature);

    Mat lab_image;
    lab_image.create(Size(image0.cols, image0.rows), 3);  
    cvtColor(image0, lab_image, CV_BGR2Lab);

    varianceCountLAB(lab_image, &feature[59]);

    /*
    for (int i = 0; i < 65; ++i)
    {
        cout<<feature[i]<<" ";
    }
    */

    int result_classify = my_svm.classify(feature);
    //cout<<result_classify<<" ";
    return result_classify;
}  