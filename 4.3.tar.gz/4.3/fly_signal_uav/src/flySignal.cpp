#include "include/flySignal.h"

FlySignal::FlySignal()
{
	//int result_judge[m1][n];
	result_judge = new int*[m1];
	for (int i = 0; i != m1; ++i)
	{
		result_judge[i] = new int[n];
	}
}

FlySignal::~FlySignal()
{
	//delete []result_judge;
	for (int i = 0; i != m1; ++i)
	{
		if (result_judge[i] != NULL)
		{
			delete []result_judge[i];
		}
	}
	delete []result_judge;
}

void FlySignal::cutImage(Mat img)
{
	int ceil_width  = img.cols/n;   
	int ceil_height = img.rows/m;  

	//cout<<"ceil_width "<<ceil_width<<" ceil_height "<<ceil_height<<endl;

	//push back the result to an array
	Mat roi_img(ceil_height, ceil_width, CV_8UC3,cv::Scalar(0,0,0));
	//Mat roi_img;

	for(int i = 0; i<m1; i++)
	{
		for(int j = 0; j<n; j++)
		{
			Rect rect(j*ceil_width, i*ceil_height, ceil_width, ceil_height);
			img(rect).copyTo(roi_img);

			result_judge[i][j] = features.getFeature_Classify(roi_img);
		}
	}

	judge_logic();

	if (flag_showArray)
	{
		result_show(img);	//img is just used for getting the rows and cols
	}

	//int controlMesssage=RoadFind(result_judge);
	//cout<<"controlMesssage "<<controlMesssage<<endl;

}

void FlySignal::judge_logic()		/*0: grass, 1: road*/
{
	
	for (int i = 1; i != m1-1; ++i)
	{
		for (int j = 1; j != n-1; ++j)
		{
			if (result_judge[i][j])
			{
				if (result_judge[i][j-1]==0&&result_judge[i][j+1]==0
					&&result_judge[i-1][j]==0&&result_judge[i+1][j]==0)
				{
					//cout<<"its been used"<<i<<" "<<j<<endl;
					result_judge[i][j]=0;
				}
			}
			else
			{
				if (result_judge[i][j-1]==1&&result_judge[i][j+1]==1
					&&result_judge[i-1][j]==1&&result_judge[i+1][j]==1)
				{
					//cout<<"its been used"<<i<<" "<<j<<endl;
					result_judge[i][j]=1;
				}
			}

		}
	}
	
}

void FlySignal::result_show(Mat img)
{
	//show the array
	for (int i = 1; i != m1; ++i)
	{
		for (int j = 0; j != n; ++j)
		{
			cout<<result_judge[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
	//cout<<"debuging"<<endl;

	//show the image colored
	int ceil_width  = img.cols/n;   
	int ceil_height = img.rows/m;  

	Mat roi_img;

	Mat img_afterColor(img.rows/2,img.cols,CV_8UC1);

	Mat roi_colorBlack(ceil_height,ceil_width,CV_8UC1,cv::Scalar(0));	//black
	Mat roi_colorWhite(ceil_height,ceil_width,CV_8UC1,cv::Scalar(255));	//white

	for(int i = 0;i<m1;i++)
	{
		for(int j = 0;j<n;j++)
		{
			Rect rect(j*ceil_width,i*ceil_height,ceil_width,ceil_height);
			img(rect).copyTo(roi_img);
			
			
			if (result_judge[i][j])
			{
				roi_colorWhite.copyTo(img_afterColor(rect));
			}
			else
			{
				roi_colorBlack.copyTo(img_afterColor(rect));
			}
		}
	}


	imshow("result_afterColor",img_afterColor);
	waitKey(10);

	//waitKey(0);

}

int FlySignal::getFlySignal(Mat img)
{
	cutImage(img);

	int fly_signal = pathPlanning.RoadFind(result_judge);
	//cout<<"fly_signal "<<fly_signal<<endl;

	return fly_signal;
}
