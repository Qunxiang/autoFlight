#include "include/PathPlanning.h"

PathPlanning::PathPlanning()
{

}

PathPlanning::~PathPlanning()
{
	
}

struct _Point
{
	int x;
	int y;
} StartPoint,FinalPoint;

int PathPlanning::RoadFind(int **result_array)
{
	//							-5-4-3-2-1 0 1 2 3 4 5
	int road_result_array[11] = {0,0,0,0,0,0,0,0,0,0,0};
	
	//0°
	//from(320,240)to(320,0)
	if (/*result_array[0][15]&&*/result_array[1][15]&&result_array[2][15]&&result_array[3][15]
		&&result_array[4][15]&&result_array[5][15]&&result_array[6][15]&&result_array[7][15]
		&&result_array[8][15]&&result_array[9][15]&&result_array[10][15]&&result_array[11][15])
	{
		road_result_array[5] = 1;
	}


	/*******************************Left*******************************/
	//left1
	if (/*result_array[0][13]&&result_array[0][14]&&*/result_array[1][14]&&result_array[2][14]
		&&result_array[3][14]&&result_array[3][15]&&result_array[4][15]&&result_array[5][15]
		&&result_array[6][15]&&result_array[7][15]&&result_array[8][15]&&result_array[9][15]
		&&result_array[10][15]&&result_array[11][15])
	{
		road_result_array[4] = 1;
	}

	//left2
	if (/*result_array[0][12]&&*/result_array[1][12]&&result_array[1][13]&&result_array[2][13]
		&&result_array[3][13]&&result_array[3][14]&&result_array[4][14]&&result_array[5][14]
		&&result_array[5][15]&&result_array[6][15]&&result_array[7][15]&&result_array[8][15]
		&&result_array[9][15]&&result_array[10][15]&&result_array[11][15])
	{
		road_result_array[3] = 1;
	}

	//left3
	if (/*result_array[0][9]&&result_array[0][10]&&*/result_array[1][10]&&result_array[1][11]
		&&result_array[2][11]&&result_array[2][12]&&result_array[3][12]&&result_array[3][13]
		&&result_array[4][13]&&result_array[4][14]&&result_array[5][14]&&result_array[6][14]
		&&result_array[6][15]&&result_array[7][15]&&result_array[8][15]&&result_array[9][15]
		&&result_array[10][15]&&result_array[11][15])
	{
		road_result_array[2] = 1;
	}

	//left4
	if (result_array[1][6]&&result_array[1][7]&&result_array[1][8]&&result_array[1][9]
		&&result_array[2][9]&&result_array[2][10]&&result_array[2][11]&&result_array[3][11]
		&&result_array[3][12]&&result_array[4][12]&&result_array[4][13]&&result_array[5][13]
		&&result_array[5][14]&&result_array[6][14]&&result_array[7][14]&&result_array[7][15]
		&&result_array[8][15]&&result_array[9][15])
	{
		road_result_array[1] = 1;
	}

	//left5
	if (result_array[3][6]&&result_array[3][7]&&result_array[3][8]&&result_array[3][9]
		&&result_array[3][10]&&result_array[3][11]&&result_array[4][11]&&result_array[4][12]
		&&result_array[5][12]&&result_array[5][13]&&result_array[6][13]&&result_array[6][14]
		&&result_array[7][14]&&result_array[7][15]&&result_array[8][15]&&result_array[9][15])
	{
		road_result_array[0] = 1;
	}



	/*******************************right*******************************/
	//right1
	if (/*result_array[0][18]&&result_array[0][17]&&*/result_array[1][17]&&result_array[2][17]
		&&result_array[3][17]&&result_array[3][16]&&result_array[4][16]&&result_array[5][16]
		&&result_array[6][16]&&result_array[7][16]&&result_array[8][16]&&result_array[9][16]
		&&result_array[10][16]&&result_array[11][16])
	{
		road_result_array[6] = 1;
	}

	//right2
	if (/*result_array[0][20]&&result_array[0][19]&&*/result_array[1][19]&&result_array[1][18]
		&&result_array[2][18]&&result_array[3][18]&&result_array[3][17]&&result_array[4][17]
		&&result_array[5][17]&&result_array[5][16]&&result_array[6][16]&&result_array[7][16]
		&&result_array[8][16]&&result_array[9][16]&&result_array[10][16]&&result_array[11][16])
	{
		road_result_array[7] = 1;
	}

	//right3
	if (/*result_array[0][22]&&result_array[0][21]&&*/result_array[1][21]&&result_array[1][20]
		&&result_array[2][20]&&result_array[2][19]&&result_array[3][19]&&result_array[3][18]
		&&result_array[4][18]&&result_array[4][17]&&result_array[5][17]&&result_array[6][17]
		&&result_array[6][16]&&result_array[7][16]&&result_array[8][16]&&result_array[9][16]
		&&result_array[10][16]&&result_array[11][16])
	{
		road_result_array[8] = 1;
	}

	//right4
	if (result_array[1][25]&&result_array[1][24]&&result_array[1][25]&&result_array[1][24]
		&&result_array[1][23]&&result_array[1][22]&&result_array[2][22]&&result_array[2][21]
		&&result_array[2][20]&&result_array[3][20]&&result_array[3][19]&&result_array[4][19]
		&&result_array[4][18]&&result_array[5][18]&&result_array[5][17]&&result_array[6][17]
		&&result_array[7][17]&&result_array[7][16]&&result_array[8][16]&&result_array[9][16])
	{
		road_result_array[9] = 1;
	}

	//right5
	if (result_array[3][24]&&result_array[3][23]&&result_array[3][24]&&result_array[3][23]
		&&result_array[3][22]&&result_array[3][23]&&result_array[3][22]&&result_array[3][21]
		&&result_array[3][22]&&result_array[3][21]&&result_array[3][20]&&result_array[4][20]
		&&result_array[4][19]&&result_array[5][19]&&result_array[5][18]&&result_array[6][18]
		&&result_array[6][17]&&result_array[7][17]&&result_array[7][16]&&result_array[8][16]
		&&result_array[9][16]&&result_array[10][16])
	{
		road_result_array[10] = 1;
	}

	//cout<< "the path we choose is: " << path_optimize(road_result_array) <<endl;
	return path_optimize(road_result_array);
}

int PathPlanning::path_optimize(int road_result_array[11])
{
	int road_result_weight = -5;
	int road_result = 0;
	int road_result_num = 0;

	for (int i = 0; i < 11; ++i)
	{
		// count the valid signal sum
		road_result_num += road_result_array[i];

		road_result += road_result_array[i]*(road_result_weight++);
	}

	if (road_result_num != 0)
	{
		std::vector<int> Vector_road_result;

		road_result /= road_result_num;

		for (int i = 0; i < 11; ++i)
		{
			if (road_result_array[i])
			{
				Vector_road_result.push_back(fabs(i-5-road_result));
			}
		}
		sort(Vector_road_result.begin(),Vector_road_result.end());

		//cout<< road_result<<endl;
		//cout<< Vector_road_result[0] <<endl<<endl;	//find the smallest one

		if (road_result >= 0)
		{
			if (road_result_array[5 + road_result - Vector_road_result[0]])
			{
				//cout<<"debugging"<<endl;
				return road_result - Vector_road_result[0];
			}
			else
			{
				return road_result + Vector_road_result[0];
			}
		}
		else
		{
			if (road_result_array[5 + road_result + Vector_road_result[0]])
			{
				return road_result + Vector_road_result[0];
			}
			else
			{
				return road_result - Vector_road_result[0];
			}
		}
	}
	else
	{
		return 100;			//找不到可行道路
	}
}




