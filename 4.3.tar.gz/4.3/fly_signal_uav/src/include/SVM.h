#include <cv.h>
#include <highgui.h>
#include <ml.h>
#include <cxcore.h>
#include <iostream>
using namespace std;
using namespace cv;

class mySVM
{
public:
	mySVM();
	~mySVM();

	//void train();
	void loadSVM();
	int classify(float a[65]);

private:
	CvSVMParams params;
	CvSVM svm;
	
	/* data */
};