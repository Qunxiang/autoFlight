#include <iostream>
#include <string.h>
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/core/core.hpp"
//#include "opencv2/features2d/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"
//#include "opencv2/nonfree/features2d.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <cmath>
using namespace cv;
using namespace std;

class PathPlanning
{
public:
	PathPlanning();
	~PathPlanning();

	int RoadFind(int **result_array);

	int path_optimize(int road_result_array[11]);

protected:

private:

};

