#include "features.h"
#include "PathPlanning.h"

#include <iostream>
#include <string.h>
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/core/core.hpp"
//#include "opencv2/features2d/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"
//#include "opencv2/nonfree/features2d.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <cmath>
#include <cv.h> 
#include <highgui.h>
#include <cxcore.h>
 
using namespace std;
using namespace cv;

class FlySignal
{
public:
	FlySignal();
	~FlySignal();

	Features features;
	PathPlanning pathPlanning;

	void cutImage(Mat img);
	int getFlySignal(Mat img);
	void judge_logic();
	void result_show(Mat img);

	int **result_judge;

private:
	enum {m = 24, m1 = 12, n = 32};
	//enum {m = 12, m1 = 6, n = 16};
	enum {flag_showArray = 0};	//显示图片数组 or 不显示

};
