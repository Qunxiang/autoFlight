#include "SVM.h"

#include <iostream>
#include <string.h>
#include <stdio.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/core/core.hpp"
//#include "opencv2/features2d/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"
//#include "opencv2/nonfree/features2d.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <cmath>
#include <cv.h> 
#include <highgui.h>
#include <cxcore.h>
#include <fstream>

#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
 
using namespace std;
using namespace cv;

class Features
{
public:
    Features();
    ~Features();

    mySVM my_svm;

    int getHopCount(int i);
    void lbp59table(uchar *table);
    void uniformLBP(Mat &image, Mat &result, uchar *table);
    void getLBPHistogram(Mat &image, float array[59]);

    void varianceCountLAB(Mat &image, float array[6]);
    int getFeature_Classify(Mat image0);

private:
    
};
