#include "include/flySignal.h"

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
//#include <opencv/cv.h>
//#include <opencv/highgui.h>

#include <cv_bridge/cv_bridge.h>
#include <stdio.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
//后加的为了显示使用的头文件
#include <string.h>
#include "std_msgs/String.h"
#include <sstream>

using namespace std;
using namespace cv;

FlySignal flySignal;

//Mat imageresize;
Mat imgForProc;
//int time_flag;
int fly_signal = 100;	//default is doing nothing

void imageCallback(const sensor_msgs::ImageConstPtr& msg)
{
	try
	{
		imgForProc = (cv_bridge::toCvShare(msg, "bgr8")->image).clone();
		//resize(cv_bridge::toCvShare(msg, "bgr8")->image,imageresize,cvSize(640,480),0,0,CV_INTER_LINEAR);
		//imshow("camera", imgForProc);
		//waitKey(10);

		//get the fly control signals
		fly_signal = flySignal.getFlySignal(imgForProc);
	}
	catch (cv_bridge::Exception& e)
	{
		ROS_ERROR("Could not convert from '%s' to 'bgr8'.", msg->encoding.c_str());
	}
}

int main(int argc, char** argv)
{
    flySignal.features.my_svm.loadSVM();
    printf("load SVM model over!\n");

	ros::init(argc, argv, "fly_signal_uav");
	ros::NodeHandle n;
	image_transport::ImageTransport it(n);

	//从摄像头camera/image_raw节点订阅图像
	image_transport::Subscriber sub = it.subscribe("/dji_sdk/image_raw", 1, imageCallback);

	ros::Publisher chatter_pub = n.advertise<std_msgs::String>("/uav/fly/signal", 1000);

	ros::Rate loop_rate(20);		//rate: 20hz

	while(ros::ok() /*&& time_flag < 1*/)	//just run one time
	{
		std_msgs::String msg;
		std::stringstream ss;
	    	ss << fly_signal;
	   	 msg.data = ss.str();
	    	//ROS_INFO("%s", msg.data.c_str());

		chatter_pub.publish(msg);

		ros::spinOnce();

		loop_rate.sleep();
	}	

	return 0;
}
