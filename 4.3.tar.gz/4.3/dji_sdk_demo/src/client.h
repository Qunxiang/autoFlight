#include <ros/ros.h>
#include "std_msgs/String.h"
#include <dji_sdk/dji_drone.h>
#include <cstdlib>
#include <actionlib/client/simple_action_client.h>
#include <actionlib/client/terminal_state.h>

#include <iostream>

using namespace std;
//using namespace cv;

class djiClient
{
public:
	djiClient();
	~djiClient();

	void Display_Main_Menu();
	
	void autoMove(DJIDrone* drone, float distance, float yaw, float degree);

	void autoFlight(DJIDrone *drone, float yaw, int fly_signal);

};
