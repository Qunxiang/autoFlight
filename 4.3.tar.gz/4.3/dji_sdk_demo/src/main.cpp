#include "client.h"

#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/Odometry.h>

//#define TEST_UAV

int fly_signal = 100;
float yaw = 0.0;

void signalCallback(const std_msgs::String::ConstPtr& msg)
{
	fly_signal = atoi(msg->data.c_str());
	//ROS_INFO("I heard: [%s]", msg->data.c_str());
	//ROS_INFO("I heard: [%d]", fly_signal);
}

void yawCallback(const nav_msgs::Odometry& msg_pose_xyzw)
{
    //用于获得当前时刻的偏航角
     float yaw_x = msg_pose_xyzw.pose.pose.orientation.x;
     float yaw_y = msg_pose_xyzw.pose.pose.orientation.y;
     float yaw_z = msg_pose_xyzw.pose.pose.orientation.z;
     float yaw_w = msg_pose_xyzw.pose.pose.orientation.w;

     yaw = atan2(2*(yaw_w*yaw_z + yaw_x*yaw_y), 1-2*(yaw_y*yaw_y + yaw_z*yaw_z));
     yaw *= (180/3.141592654);
     //cout<<"yaw: "<<yaw<<endl;
}
 
int main(int argc, char **argv)
{
    djiClient uavClient;

    int main_operate_code = 0;
    int temp32;
    bool valid_flag = false;
    bool err_flag = false;
    ros::init(argc, argv, "sdk_client");
    ROS_INFO("sdk_service_client_test");
    ros::NodeHandle nh;
    DJIDrone* drone = new DJIDrone(nh);

    dji_sdk::WaypointList newWaypointList;
    dji_sdk::Waypoint waypoint0;
    dji_sdk::Waypoint waypoint1;
    dji_sdk::Waypoint waypoint2;
    dji_sdk::Waypoint waypoint3;
    dji_sdk::Waypoint waypoint4;

    //show a menu to cmd the uav
    uavClient.Display_Main_Menu();

    ros::Subscriber sub = nh.subscribe("/uav/fly/signal", 1000, signalCallback);

    ros::Subscriber sub_yaw = nh.subscribe("/dji_sdk/odometry", 1000, yawCallback);

#ifdef TEST_UAV
    while(1)
    {
        //cout<<"yaw: "<<yaw<<endl;
    
    	ros::spinOnce();
    	temp32 = getchar();

    	if(temp32 != 10)
        {
            if(temp32 >= 'a' && temp32 <= 'z' && valid_flag == false)
            {
                main_operate_code = temp32;
                valid_flag = true;
            }
            else
            {
                err_flag = true;
            }
            continue;
        }
        else
        {
            if(err_flag == true)
            {
                printf("input: ERROR\n");
                uavClient.Display_Main_Menu();
                err_flag = valid_flag = false;
                continue;
            }
        }
        
        switch(main_operate_code)
        {
        	case 'a':
                /* request control ability*/
                drone->request_sdk_permission_control();
                break;
            case 'b':
                /* release control ability*/
                drone->release_sdk_permission_control();
                break;
            case 'c':
                /* take off */
                drone->takeoff();
                break;
            case 'd':
                /* landing*/
                drone->landing();
                break;
            case 'e':
                /* go home*/
                drone->gohome();
                break;

            case 'f':
                /*gimbal control*/
                drone->gimbal_angle_control(0, -850, 0, 20);
                sleep(2);
                break;

	    case 'g':
                /*gimbal return*/
                drone->gimbal_angle_control(0, 0, 0, 20);
                sleep(2);
                break;

            /*
             *wang
             *
             *auto move test
             */    
            case 'h':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, 0);
                break;
                                  
            case 'p':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, -7);
                break;
            case 'q':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, -14);
                break;
            case 'r':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, -21);
                break;
            case 's':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, -28);
                break;
            case 't':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, 7);
                break;
            case 'u':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, 14);
                break;
            case 'v':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, 21);
                break;
            case 'w':
                /*right straight*/
                uavClient.autoMove(drone, 0.3, yaw, 28);
                break;

            case 'z':
                return 0;

            default:
                break;
        }

        main_operate_code = -1;
        err_flag = valid_flag = false;
        uavClient.Display_Main_Menu();
    }

#else
    //auto flight

    uavClient.Display_Main_Menu();

    temp32 = getchar();
    if(temp32 != 10)
    {
        if(temp32 >= 'a' && temp32 <= 'z' && valid_flag == false)
        {
            main_operate_code = temp32;
            valid_flag = true;
        }
        else
        {
            err_flag = true;
        }
    }
    else
    {
        if(err_flag == true)
        {
            printf("input: ERROR\n");
            uavClient.Display_Main_Menu();
            err_flag = valid_flag = false;
        }
    }

    ros::Rate loop_rate(1);        //rate: 1

    if (temp32 == 'x')
    {
        /* request control ability*/
        drone->request_sdk_permission_control();
        sleep(2);

        //first, control the camera downward
        drone->gimbal_angle_control(0, -900, 0, 20);
        sleep(2);
     
        //auto takeoff   
        /*
        drone->takeoff();
        sleep(2);
        */
        
        /*
        for(int i = 0; i < 60; i++)
        {
            drone->attitude_control(HORIZ_POS|VERT_VEL|YAW_ANG|HORIZ_BODY|YAW_BODY, 0, 0, 1, 0);
            usleep(20000);
        }
        sleep(2);
        */

        while(ros::ok())
        {
            if (fly_signal != 100)
            {
                uavClient.autoFlight(drone, yaw, fly_signal);
            }

            ros::spinOnce();
            //loop_rate.sleep();
        }
        
        
        /*
        // return the camera status
        drone->gimbal_angle_control(0, 0, 0, 20);
        sleep(2);
        // release control ability
        drone->release_sdk_permission_control();
        */
        
        main_operate_code = -1;
        err_flag = valid_flag = false;
    }
        
#endif

	return 0;
}
