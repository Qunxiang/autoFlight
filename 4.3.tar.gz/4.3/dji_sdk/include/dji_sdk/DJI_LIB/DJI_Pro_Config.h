#ifndef __DJI_PRO_CONFIG_H__
#define __DJI_PRO_CONFIG_H__

#define MEMORY_SIZE				1000   //unit is byte

#endif
